// import 'dart:convert';
// import 'package:flutter/services.dart';
// import 'package:get/get.dart';
// import 'package:http/http.dart' as http;
// import '../models/DailyExerciseModel.dart';
//
// class GoalsController extends GetxController{
//   List<DailyExerciseModel> exerciseList =[];
//   Future<void> readJsonGoals() async{
//     final  String response = await rootBundle.loadString('resources/files/assets1.json');
//     final data = await json.decode(response);
//     data["daily_exercices"].forEach((item){
//       exerciseList.add(DailyExerciseModel(
//           title: item["title"],
//           cover: item["cover"],
//           calories_count: item["calories_count"],
//           duration_seconds: item["duration_seconds"]
//       ));
//     });
//   }
// }
