class Path{
  static String pathToJson = 'resources/files/assets1.json';
}