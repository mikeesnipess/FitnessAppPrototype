import 'dart:convert';
import 'dart:ui';
import 'package:fitness_app/presentation/home/models/GoalsDataModel.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../models/DailyExerciseModel.dart';
import '../models/ResponseModel.dart';
import '../controller/Path.dart';
class HomeController extends GetxController{
  RxList<GoalsDataModel> goalsList = RxList();
  RxList<DailyExerciseModel> exercisesList = RxList();
  void readJsonFile() async {
    String jsonString = await rootBundle.loadString(Path.pathToJson);
    var map = await jsonDecode(jsonString);
    var mapResponse = ResponseModel.fromJson(map);
    goalsList.value = mapResponse.goals
        .map((e) => GoalsDataModel(
        cover: e.cover,
        title: e.title,
        subTitle: e.subTitle,
        caloriesCount: e.caloriesCount,
        durationSeconds: e.durationSeconds))
        .toList();
    exercisesList.value = mapResponse.exercises
        .map((e) => DailyExerciseModel(
        title: e.title,
        cover: e.cover,
        caloriesCount: e.caloriesCount,
        durationSeconds: e.durationSeconds)).toList();
  }
}