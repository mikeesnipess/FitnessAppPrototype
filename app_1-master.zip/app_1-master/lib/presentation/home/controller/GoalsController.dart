// import 'dart:convert';
// import 'package:flutter/services.dart';
// import 'package:get/get.dart';
// import 'package:http/http.dart' as http;
// import '../models/GoalsDataModel.dart';
//
// class GoalsController extends GetxController{
//   List<GoalsDataModel> goalsList =[];
//   Future<void> readJsonGoals() async{
//     final  String response = await rootBundle.loadString('resources/files/assets1.json');
//     final data = await json.decode(response);
//     data["goals"].forEach((item){
//       goalsList.add(GoalsDataModel(
//         cover: item["cover"],
//         title: item["title"],
//         sub_title: item["sub_title"],
//         calories_count: item["calories_count"],
//         duration_seconds: item["duration_seconds"]
//       ));
//     });
//   }
// }
