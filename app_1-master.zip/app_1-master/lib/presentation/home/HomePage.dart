import 'package:fitness_app/presentation/home/widgets/daily_exercise.dart';
import 'package:fitness_app/presentation/home/widgets/goals_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'controller/HomeController.dart';
class HomePage extends StatefulWidget {
  HomePage({super.key});
  @override
  _HomePage createState() => _HomePage();
}
class _HomePage extends State<HomePage> {
  _HomePage();
  final homeController = Get.put(HomeController());
  @override
  void initState() {
    Get.lazyPut(() => HomeController());
    HomeController controller = Get.find();
    controller.readJsonFile();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    HomeController controller = Get.find();
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: Size.fromHeight(0.0), // here the desired height
            child: AppBar()),
        body: Column(
          children: <Widget>[
            Obx( () => controller.goalsList.isNotEmpty
                ? GoalsSection(goals: controller.goalsList)
                : const Center(child: CircularProgressIndicator())
            ),
            Obx( () => controller.exercisesList.isNotEmpty
                ? DailyTaskSection(exercises: controller.exercisesList)
                : const Center(child: CircularProgressIndicator())
            )
          ],
        )
    );
  }
}