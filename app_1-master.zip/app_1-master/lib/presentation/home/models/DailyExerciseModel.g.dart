// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'DailyExerciseModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DailyExerciseModel _$DailyExerciseModelFromJson(Map<String, dynamic> json) =>
    DailyExerciseModel(
      title: json['title'] as String,
      cover: json['cover'] as String,
      caloriesCount: json['calories_count'] as int,
      durationSeconds: json['duration_seconds'] as int,
    );

Map<String, dynamic> _$DailyExerciseModelToJson(DailyExerciseModel instance) =>
    <String, dynamic>{
      'title': instance.title,
      'cover': instance.cover,
      'calories_count': instance.caloriesCount,
      'duration_seconds': instance.durationSeconds,
    };
