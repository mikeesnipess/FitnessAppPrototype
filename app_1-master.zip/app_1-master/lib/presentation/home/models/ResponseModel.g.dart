// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ResponseModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseModel _$ResponseModelFromJson(Map<String, dynamic> json) =>
    ResponseModel(
      (json['goals'] as List<dynamic>)
          .map((e) => GoalsDataModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      (json['daily_exercises'] as List<dynamic>)
          .map((e) => DailyExerciseModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ResponseModelToJson(ResponseModel instance) =>
    <String, dynamic>{
      'goals': instance.goals,
      'daily_exercises': instance.exercises,
    };
