import 'package:json_annotation/json_annotation.dart';

part 'DailyExerciseModel.g.dart';

@JsonSerializable()

class DailyExerciseModel{
  final String title;
  final String cover;
  @JsonKey(name:'calories_count')
  final int caloriesCount;
  @JsonKey(name:'duration_seconds')
  final int durationSeconds;


  DailyExerciseModel({
    required this.title,
    required this.cover,
    required this.caloriesCount,
    required this.durationSeconds});

  factory DailyExerciseModel.fromJson(Map<String, dynamic> json)=>_$DailyExerciseModelFromJson(json);
  Map<String,dynamic> toJson() =>_$DailyExerciseModelToJson(this);
}