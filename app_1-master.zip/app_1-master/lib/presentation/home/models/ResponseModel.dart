import 'package:json_annotation/json_annotation.dart';
import 'DailyExerciseModel.dart';
import 'GoalsDataModel.dart';

part 'ResponseModel.g.dart';

@JsonSerializable()
class ResponseModel{
  final List<GoalsDataModel> goals;
  @JsonKey(name:'daily_exercises')
  final List<DailyExerciseModel> exercises;

  ResponseModel(this.goals, this.exercises);
  factory ResponseModel.fromJson(Map<String, dynamic> json)=> _$ResponseModelFromJson(json);
  Map<String, dynamic> toJson()=>_$ResponseModelToJson(this);
}
