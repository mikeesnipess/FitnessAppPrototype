class Files {
  static String jsonFilePath = 'resources/files/assets.json';
}