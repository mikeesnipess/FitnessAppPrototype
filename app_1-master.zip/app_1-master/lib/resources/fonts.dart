class Fonts {
  static const signikaRegular = 'Signika-Regular';
  static const poppinsSemiBold = 'Poppins-SemiBold';
  static const poppinsMedium = 'Poppins-Medium';
}