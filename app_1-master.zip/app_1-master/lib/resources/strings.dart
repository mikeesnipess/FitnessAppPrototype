class Strings {
  static String activity  = 'Start New Goal';
  static String activity1  = 'See all';
  static String activity2 = 'Daily Task';
}